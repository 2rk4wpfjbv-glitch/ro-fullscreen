# RO Fullscreen

RO Survivors (https://ro-survivors.com/) を専用の UIKit / WKWebView アプリで開く個人用プロジェクトです。ゲーム本体の複製や他プロジェクトのコードは含みません。ゲーム運営とは関係のない非公式アプリです。

## 表示

- iOS 27.1 以降の SDK でビルド（Xcode 27.1 未満では CI を停止）。
- Scene ベースのウィンドウ、ステータスバー非表示、ホームインジケーター自動非表示。
- WebView を Safe Area ではなく親ビューの四辺に配置。スクロールの自動余白を無効化。
- viewport-fit=cover を設定。回転と開閉によるサイズ変更は Auto Layout と WebKit で追従。
- Cookie / Web Storage は端末内に永続保存。Safari の保存データとは別です。
- 読み込み失敗時に再接続ボタンを表示。JavaScript の確認・入力ダイアログをサポート。

カメラなど物理的に表示できない部分は描画できません。システムジェスチャーはOSが管理します。ゲーム側の表示やタッチ座標を壊さないよう、canvas の縦横比を強制的に引き伸ばしていません。右端の表示・開閉・音声・ログイン・ゲームプレイの最終確認は iPhone Duo 実機で必要です。

## 無料ビルド

このフォルダーの中身だけを専用の公開 GitHub リポジトリ `ro-fullscreen` の main ブランチに入れます。他プロジェクトのファイルをアップロードしないでください。

GitHub Actions の `Build RO Fullscreen IPA` は標準 `xcode-27` ランナーを使用します。公開リポジトリのみ実行し、非公開ではスキップします。大型の有料ランナー、有料Apple Developer契約、外部ビルドサービスは使用しません。

Actions の成果物 `ROFullscreen-build` から `ROFullscreen-unsigned.ipa` を取得します。これは実機用バイナリですが、署名前なのでタップするだけではインストールできません。Apple ID の情報や証明書を GitHub に保存する必要はありません。

CI はXcode/SDK確認、viewportテスト、実機用archive、IPA構造検証、SHA-256出力を実行します。Duoシミュレーターがある場合は起動とスクリーンショットも生成します。スクリーンショット生成だけでゲームの動作確認が完了したとは扱いません。コンパイルエラーはActionsログをもとに修正する必要があり、このワークフロー自身がコードを自動修正するわけではありません。

## Windows と iPhone で導入

無料の AltStore Classic / AltServer を使用できます。Windows公式手順:
https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows

1. 公式手順で必要なAppleソフトとAltServerを用意します。
2. iPhoneを接続し、このコンピューターを信頼します。
3. AltServerで自分のApple Accountを認証し、AltStoreをインストールします。パスワードや認証コードをチャットやGitHubに送らないでください。
4. iPhoneで必要な開発者モード・プロファイルの信頼設定を行います。
5. IPAをiPhoneの「ファイル」に保存し、AltStoreのMy Appsの「+」から選択して署名・インストールします。
6. 無料署名は7日で期限切れになるため、AltServerへ接続できる状態で定期更新します。無料のまま永久署名はできません。

すでに Sideloadly を使っている場合は、同じIPAをWindowsから署名・導入する代替手段として利用できます。利用中のOSとの互換性は導入時に確認してください。

## ローカル確認

Windows: `python scripts/generate_project.py`、`node tests/viewport.test.cjs`

Mac（Xcode 27.1以上）: `bash scripts/build.sh`

## 参考資料

- https://developer.apple.com/iphone-duo/prepare/
- https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- https://github.com/actions/runner-images/blob/main/images/macos/xcode-27-arm64-Readme.md
- https://faq.altstore.io/altstore-classic/your-altstore
