(() => {
  'use strict';
  if (location.origin !== 'https://ro-survivors.com') return;
  function configureViewport() {
    let meta = document.querySelector('meta[name="viewport"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'viewport';
      document.head.appendChild(meta);
    }
    const values = (meta.content || '').split(',').map(v => v.trim()).filter(Boolean);
    const kept = values.filter(v => !/^(width|initial-scale|viewport-fit)\s*=/i.test(v));
    const content = [...kept, 'width=device-width', 'initial-scale=1', 'viewport-fit=cover'].join(', ');
    if (meta.content !== content) meta.content = content;
  }
  configureViewport();
  new MutationObserver(configureViewport).observe(document.head, {
    childList: true, subtree: true, attributes: true, attributeFilter: ['content']
  });
  const style = document.createElement('style');
  style.textContent = `
    html, body { margin: 0 !important; width: 100% !important; min-height: 100%; }
    html { background: #000; }
    body { overscroll-behavior: none; }
  `;
  document.head.appendChild(style);
  // Leave canvas sizing and input handling to the game: stretching a canvas
  // independently of its renderer breaks touch coordinates.
})();
