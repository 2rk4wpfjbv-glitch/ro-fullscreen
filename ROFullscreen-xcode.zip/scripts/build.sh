#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build dist
python3 scripts/check_toolchain.py
python3 scripts/generate_project.py
xcodebuild -version | tee dist/toolchain.txt
xcrun --sdk iphoneos --show-sdk-version | tee -a dist/toolchain.txt
plutil -lint ROFullscreen/Info.plist ROFullscreen.xcodeproj/project.pbxproj
xcodebuild -project ROFullscreen.xcodeproj -scheme ROFullscreen \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath build/ROFullscreen.xcarchive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO archive 2>&1 | tee build/archive.log
APP=build/ROFullscreen.xcarchive/Products/Applications/ROFullscreen.app
test -f "$APP/ROFullscreen"
test -f "$APP/fullscreen.js"
# These are unsigned device binaries, for local signing by AltStore Classic.
mkdir -p build/package/Payload
ditto "$APP" build/package/Payload/ROFullscreen.app
(cd build/package && /usr/bin/zip -qry ../../dist/ROFullscreen-unsigned.ipa Payload)
python3 scripts/verify_ipa.py dist/ROFullscreen-unsigned.ipa
shasum -a 256 dist/ROFullscreen-unsigned.ipa > dist/SHA256SUMS.txt
