"""Check the active toolchain before any archive, including local Mac builds."""
import re
import subprocess

def parts(value):
    return tuple(map(int, value.split('.')[:2]))

output = subprocess.check_output(['xcodebuild', '-version'], text=True)
match = re.search(r'Xcode (\d+\.\d+)', output)
if not match or parts(match[1]) < (27, 1):
    raise SystemExit('Xcode 27.1 or newer is required.')
sdk = subprocess.check_output(['xcrun', '--sdk', 'iphoneos', '--show-sdk-version'], text=True).strip()
if parts(sdk) < (27, 1):
    raise SystemExit('iOS SDK 27.1 or newer is required.')
print(output.strip(), '\niOS SDK', sdk)
