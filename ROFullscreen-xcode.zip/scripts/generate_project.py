"""Generate a self-contained Xcode project using only Python's standard library."""
import hashlib
import json
import plistlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'ROFullscreen'
PROJECT = ROOT / 'ROFullscreen.xcodeproj'

def ident(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()

def generate():
    PROJECT.mkdir(exist_ok=True)
    info = {
        'CFBundleDevelopmentRegion': 'ja',
        'CFBundleDisplayName': 'RO Fullscreen',
        'CFBundleExecutable': '$(EXECUTABLE_NAME)',
        'CFBundleIdentifier': '$(PRODUCT_BUNDLE_IDENTIFIER)',
        'CFBundleInfoDictionaryVersion': '6.0',
        'CFBundleName': '$(PRODUCT_NAME)',
        'CFBundlePackageType': 'APPL',
        'CFBundleShortVersionString': '1.0',
        'CFBundleVersion': '1',
        'LSRequiresIPhoneOS': True,
        'UILaunchScreen': {},
        'UIStatusBarHidden': True,
        'UIViewControllerBasedStatusBarAppearance': True,
        'UISupportedInterfaceOrientations': [
            'UIInterfaceOrientationPortrait', 'UIInterfaceOrientationPortraitUpsideDown',
            'UIInterfaceOrientationLandscapeLeft', 'UIInterfaceOrientationLandscapeRight'],
        'UIApplicationSceneManifest': {
            'UIApplicationSupportsMultipleScenes': False,
            'UISceneConfigurations': {'UIWindowSceneSessionRoleApplication': [{
                'UISceneConfigurationName': 'Game',
                'UISceneDelegateClassName': '$(PRODUCT_MODULE_NAME).SceneDelegate'}]}}
    }
    (APP / 'Info.plist').write_bytes(plistlib.dumps(info))
    objects = {}
    def obj(key, **fields):
        objects[ident(key)] = fields
        return ident(key)
    sources, resources, refs = [], [], []
    for filename in ['AppDelegate.swift', 'GameViewController.swift', 'fullscreen.js']:
        swift = filename.endswith('.swift')
        ref = obj(filename, isa='PBXFileReference', path=filename,
                  lastKnownFileType='sourcecode.swift' if swift else 'sourcecode.javascript', sourceTree='<group>')
        refs.append(ref)
        build = obj('build'+filename, isa='PBXBuildFile', fileRef=ref)
        (sources if swift else resources).append(build)
    refs.append(obj('plist', isa='PBXFileReference', path='Info.plist', lastKnownFileType='text.plist.xml', sourceTree='<group>'))
    product = obj('product', isa='PBXFileReference', path='ROFullscreen.app', explicitFileType='wrapper.application', sourceTree='BUILT_PRODUCTS_DIR')
    group = obj('appgroup', isa='PBXGroup', path='ROFullscreen', children=refs, sourceTree='<group>')
    products = obj('products', isa='PBXGroup', name='Products', children=[product], sourceTree='<group>')
    main = obj('main', isa='PBXGroup', children=[group, products], sourceTree='<group>')
    phases = []
    for name, kind, files in [('sources','PBXSourcesBuildPhase',sources), ('resources','PBXResourcesBuildPhase',resources), ('frameworks','PBXFrameworksBuildPhase',[])]:
        phases.append(obj(name, isa=kind, buildActionMask=2147483647, files=files, runOnlyForDeploymentPostprocessing=0))
    configs = []
    project_configs = []
    for mode in ['Debug','Release']:
        project_configs.append(obj('project'+mode, isa='XCBuildConfiguration', name=mode, buildSettings={
            'SDKROOT':'iphoneos', 'IPHONEOS_DEPLOYMENT_TARGET':'17.0', 'CLANG_ENABLE_MODULES':'YES',
            'SWIFT_VERSION':'5.0', 'DEBUG_INFORMATION_FORMAT':'dwarf-with-dsym' if mode == 'Release' else 'dwarf'}))
        configs.append(obj('target'+mode, isa='XCBuildConfiguration', name=mode, buildSettings={
            'PRODUCT_BUNDLE_IDENTIFIER':'com.rofullscreen.game', 'PRODUCT_NAME':'$(TARGET_NAME)',
            'INFOPLIST_FILE':'ROFullscreen/Info.plist', 'TARGETED_DEVICE_FAMILY':'1,2',
            'SUPPORTED_PLATFORMS':'iphoneos iphonesimulator', 'SUPPORTS_MACCATALYST':'NO',
            'SWIFT_OPTIMIZATION_LEVEL':'-O' if mode == 'Release' else '-Onone',
            'CODE_SIGN_STYLE':'Automatic', 'LD_RUNPATH_SEARCH_PATHS':['$(inherited)','@executable_path/Frameworks']}))
    target_list = obj('targetconfigs', isa='XCConfigurationList', buildConfigurations=configs, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')
    project_list = obj('projectconfigs', isa='XCConfigurationList', buildConfigurations=project_configs, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')
    target = obj('target', isa='PBXNativeTarget', name='ROFullscreen', productName='ROFullscreen', productType='com.apple.product-type.application', productReference=product, buildConfigurationList=target_list, buildPhases=phases, dependencies=[], buildRules=[])
    project = obj('project', isa='PBXProject', attributes={'LastUpgradeCheck':'2710'}, buildConfigurationList=project_list, compatibilityVersion='Xcode 14.0', developmentRegion='ja', knownRegions=['ja','en','Base'], mainGroup=main, productRefGroup=products, projectDirPath='', projectRoot='', targets=[target])
    def encode(value):
        if isinstance(value, dict):
            return '{\n' + '\n'.join(f'{json.dumps(str(k))} = {encode(v)};' for k,v in value.items()) + '\n}'
        if isinstance(value, list):
            return '(' + ', '.join(encode(v) for v in value) + (',' if value else '') + ')'
        return str(value) if isinstance(value, int) else json.dumps(value)
    (PROJECT / 'project.pbxproj').write_text('// !$*UTF8*$!\n' + encode({'archiveVersion':1,'classes':{},'objectVersion':56,'objects':objects,'rootObject':project}), encoding='utf-8')
    scheme_dir = PROJECT / 'xcshareddata' / 'xcschemes'
    scheme_dir.mkdir(parents=True, exist_ok=True)
    reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="ROFullscreen.app" BlueprintName="ROFullscreen" ReferencedContainer="container:ROFullscreen.xcodeproj"/>'
    (scheme_dir / 'ROFullscreen.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2710" version="1.3">
 <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{reference}</BuildActionEntry></BuildActionEntries></BuildAction>
 <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></LaunchAction>
 <AnalyzeAction buildConfiguration="Debug"/>
 <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''', encoding='utf-8')
    print('Generated ROFullscreen.xcodeproj')

if __name__ == '__main__':
    generate()
