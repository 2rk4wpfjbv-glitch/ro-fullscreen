import os
import re
import subprocess
from pathlib import Path

def version(value):
    return tuple(int(v) for v in value.split('.')[:2])

candidates = []
for app in Path('/Applications').glob('Xcode*.app'):
    developer = app / 'Contents/Developer'
    env = dict(os.environ, DEVELOPER_DIR=str(developer))
    result = subprocess.run(['xcodebuild', '-version'], env=env, capture_output=True, text=True)
    match = re.search(r'Xcode (\d+\.\d+)', result.stdout)
    if result.returncode == 0 and match and version(match[1]) >= (27, 1):
        candidates.append((version(match[1]), str(developer)))
if not candidates:
    raise SystemExit('Xcode >= 27.1 is required. Refusing to build with an older SDK.')
_, developer = max(candidates)
with open(os.environ['GITHUB_ENV'], 'a') as f:
    f.write(f'DEVELOPER_DIR={developer}\n')
env = dict(os.environ, DEVELOPER_DIR=developer)
sdk = subprocess.check_output(['xcrun','--sdk','iphoneos','--show-sdk-version'], env=env, text=True).strip()
if version(sdk) < (27, 1):
    raise SystemExit(f'iOS SDK >= 27.1 required; found {sdk}')
print(f'Selected {developer}; iOS SDK {sdk}')
