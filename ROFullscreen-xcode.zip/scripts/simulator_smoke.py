"""Launch on an available Duo simulator; screenshot is evidence, not a gameplay test."""
import json
import subprocess
import time
from pathlib import Path

def run(*args):
    return subprocess.check_output(args, text=True)

devices = json.loads(run('xcrun','simctl','list','devices','available','-j'))['devices']
duos = [d for entries in devices.values() for d in entries if 'Duo' in d['name']]
if not duos:
    Path('dist/simulator-status.txt').write_text('No iPhone Duo simulator installed. Fullscreen and gameplay remain unverified.\n')
    print('::warning::No Duo simulator installed; device IPA is still available.')
    raise SystemExit(0)
device = duos[0]
with open('build/simulator.log','w') as log:
    subprocess.run(['xcodebuild','-project','ROFullscreen.xcodeproj','-scheme','ROFullscreen',
        '-configuration','Debug','-sdk','iphonesimulator','-destination',f"id={device['udid']}",
        '-derivedDataPath','build/simulator','CODE_SIGNING_ALLOWED=NO','build'], stdout=log, stderr=subprocess.STDOUT, check=True)
if device['state'] != 'Booted':
    run('xcrun','simctl','boot',device['udid'])
run('xcrun','simctl','bootstatus',device['udid'],'-b')
run('xcrun','simctl','install',device['udid'],'build/simulator/Build/Products/Debug-iphonesimulator/ROFullscreen.app')
launch = run('xcrun','simctl','launch',device['udid'],'com.rofullscreen.game')
time.sleep(12)
run('xcrun','simctl','io',device['udid'],'screenshot','dist/duo-launch.png')
Path('dist/simulator-status.txt').write_text(f"Launched on {device['name']}: {launch}\nInspect duo-launch.png. Fold/unfold, login, sound, and gameplay still require manual device checks.\n")
