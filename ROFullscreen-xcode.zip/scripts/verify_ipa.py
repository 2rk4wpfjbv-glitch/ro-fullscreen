import plistlib
import sys
import zipfile

with zipfile.ZipFile(sys.argv[1]) as archive:
    base = 'Payload/ROFullscreen.app/'
    names = archive.namelist()
    assert base + 'ROFullscreen' in names, 'Missing executable'
    assert base + 'fullscreen.js' in names, 'Missing viewport script'
    info = plistlib.loads(archive.read(base + 'Info.plist'))
    assert info['CFBundleIdentifier'] == 'com.rofullscreen.game'
    assert info['CFBundleSupportedPlatforms'] == ['iPhoneOS'], 'Simulator build cannot be installed'
    assert info['UIStatusBarHidden'] is True
    sdk = info['DTSDKName'].removeprefix('iphoneos')
    assert tuple(map(int, sdk.split('.')[:2])) >= (27, 1), sdk
    assert archive.read(base + 'ROFullscreen')[:4] in (b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe'), 'Not Mach-O'
print('Verified unsigned iOS device IPA; Apple account signing still required.')
