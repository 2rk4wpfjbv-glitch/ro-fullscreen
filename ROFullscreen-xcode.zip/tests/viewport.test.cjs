const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const code = fs.readFileSync('ROFullscreen/fullscreen.js', 'utf8');
function page(initial, origin = 'https://ro-survivors.com') {
  let meta = initial === null ? null : {content: initial};
  let callback;
  const children = [];
  const document = {
    querySelector: () => meta,
    createElement: tag => ({tag, content: ''}),
    head: {appendChild: el => {children.push(el); if(el.name === 'viewport') meta = el;}}
  };
  vm.runInNewContext(code, {document, location: {origin}, MutationObserver: class {
    constructor(cb) {callback = cb;} observe() {}
  }});
  return {get meta() {return meta;}, children, update: () => callback()};
}
for (const initial of [null, '', 'width=980, initial-scale=0.5, viewport-fit=contain, maximum-scale=3']) {
  const p = page(initial);
  assert.match(p.meta.content, /width=device-width/);
  assert.match(p.meta.content, /viewport-fit=cover/);
  assert.doesNotMatch(p.meta.content, /width=980|viewport-fit=contain/);
  const once = p.meta.content;
  p.update();
  assert.equal(p.meta.content, once, 'Observer must settle without a mutation loop');
  if (initial) assert.match(p.meta.content, /maximum-scale=3/);
  p.meta.content = 'width=980';
  p.update();
  assert.match(p.meta.content, /width=device-width/);
}
assert.equal(page(null, 'https://example.com').children.length, 0);
console.log('Viewport checks passed: create, preserve, replace, idempotence, site isolation.');
